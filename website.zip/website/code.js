const bookingForm = document.getElementById('BookingForm');
const duration = document.getElementById('duration');
const totalCost = document.getElementById('totalCost');
const instrumentSelect = document.getElementById('instrument');

const instrument = document.getElementById('instrument');
const dateInput = document.getElementById('date');

const prices = {
    recording: 250,
    renatal: 150,
    training: 200
};
// Set the minimum date for the date input to today
const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split('T')[0];
dateinput.min = localDate;
// Function to calculate the total cost based on selected service and duration
function calculateTotalCost() {
    let selectedService = service.value;
    let selectedDuration = Number(duration.value);

    if (selectedService === "") {
        total.textContent = "0";
        return;
    }

    let price = prices[selectedService];

    let total = price * selectedDuration;
    total.textContent = finalPrice;
}

service.addEventListener("change", function() {
    calculateTotalCost();
    if (service.value === "rental") {
        instrumentSection.hidden = false;
        instrument.required = true;
    } else {
        instrumentSection.hidden = true;
        instrument.required = false;
        instrument.value = "";
    }
});

duration.addEventListener("input", calculateTotalCost);

bookingForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const selectedService = document.getElementById('service').value;
    const selectedDate = document.getElementById('date').value;
    const selectedDuration = document.getElementById('duration').value;
    const selectedInstrument = document.getElementById('instrument').value;
    const selectedTime = document.getElementById('time').value;

});

if (!/^[0-9+\-\s()]{7,20}$/.test(phone)) {
    alert("Please enter a valid phone number.");
    return;
}

if (selectedDate < localDate) {
    alert("Please select a future date.");
    return;
}

if (selectedTime < "09:00" || selectedTime > "21:00") {
    alert("Please select a time between 09:00 and 21:00.");
    return;
}

const finalPrice = prices[selectedService] * Number(selectedDuration);

const booking = {
    name: name,
    email: email,
    phone: phone,
    service: selectedService,
    date: selectedDate,
    time: selectedTime,
    duration: selectedDuration,
    instrument: selectedInstrument,
    totalCost: finalPrice
};

let bookings = JSON.parse(localStorage.getItem('bookings')) || [];
bookings.push(booking);
localStorage.setItem('bookings', JSON.stringify(bookings));

confirmation.innerHTML = `
    <h2>Booking Confirmation</h2>
    <p>Thank you, ${name}, for your booking!</p>
    <p>Service: ${selectedService}</p>
    <p>Date: ${selectedDate}</p>
    <p>Time: ${selectedTime}</p>
    <p>Duration: ${selectedDuration} hour(s)</p>
    ${selectedService === "rental" ? `<p>Instrument: ${selectedInstrument}</p>` : ""}
    <p>Total Cost: $${finalPrice}</p>
`;

bookingForm.reset();
instrumentSection.hidden = true;
instrument.required = false;
totalCost.textContent = "0";

//contact form
const contactForm = document.getElementById('contactForm');
contactForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const contactName = document.getElementById("contactName").value;
    const contactEmail = document.getElementById("contactEmail").value;
    const contactMessage = document.getElementById("contactMessage").value;
    
    document.getElementById('contactResponse').textContent = "Thank you for reaching out! We will get back to you soon.";
    
    console.log("Contact details:");
    console.log("Name:", contactName);
    console.log("Email:", contactEmail);
    console.log("Message:", contactMessage);

    contactForm.reset();
});

document.addEventListener("DOMContentLoaded", function () {

    const questions = document.querySelectorAll(".faq-question");

    questions.forEach(function (question) {

        question.addEventListener("click", function () {

            const answer = question.nextElementSibling;
            const icon = question.querySelector("span");

            // Close all other answers
            document.querySelectorAll(".faq-answer").forEach(function (item) {
                if (item !== answer) {
                    item.style.maxHeight = null;
                    item.previousElementSibling.querySelector("span").textContent = "+";
                }
            });

            // Toggle the selected answer
            if (answer.style.maxHeight) {
                answer.style.maxHeight = null;
                icon.textContent = "+";
            } else {
                answer.style.maxHeight = answer.scrollHeight + "px";
                icon.textContent = "-";
            }

        });

    });

});